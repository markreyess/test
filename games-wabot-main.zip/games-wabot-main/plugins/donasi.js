let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Indosat [085692006004]
│ • Gopay [081212050232]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? Wa.me/6285692006004
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
